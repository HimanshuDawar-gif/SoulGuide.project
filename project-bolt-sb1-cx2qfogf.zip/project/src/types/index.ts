export interface Message {
  id: string;
  type: 'user' | 'guide';
  content: string;
  timestamp: Date;
}

export interface JournalPrompt {
  id: string;
  title: string;
  prompt: string;
  category: 'self-discovery' | 'healing' | 'growth' | 'purpose' | 'relationships';
}

export interface MeditationExercise {
  id: string;
  title: string;
  description: string;
  durationMinutes: number;
  audioUrl?: string;
}

export interface SpiritualResource {
  id: string;
  title: string;
  description: string;
  type: 'book' | 'article' | 'practice' | 'video';
  link?: string;
}

export interface UserPreference {
  spiritualInterests: string[];
  experienceLevel: 'beginner' | 'intermediate' | 'advanced';
  preferredPractices: string[];
  favoriteResources: string[];
}