import React, { useState, useEffect } from 'react';
import { affirmations } from '../data/guidanceMessages';
import { getRandomItem } from '../utils/helpers';
import { Sparkles } from 'lucide-react';
import Card, { CardContent } from './ui/Card';

const DailyAffirmation: React.FC = () => {
  const [affirmation, setAffirmation] = useState('');

  useEffect(() => {
    setAffirmation(getRandomItem(affirmations));
  }, []);

  return (
    <Card className="bg-gradient-to-r from-secondary/20 to-primary/20 border-none shadow-lg">
      <CardContent className="text-center py-6">
        <div className="flex justify-center mb-3">
          <div className="bg-primary/10 p-2 rounded-full">
            <Sparkles className="h-6 w-6 text-primary" />
          </div>
        </div>
        
        <h3 className="text-lg font-medium text-gray-700 mb-2">
          Today's Affirmation
        </h3>
        
        <p className="text-xl font-serif italic text-gray-800">
          "{affirmation}"
        </p>
        
        <div className="mt-4 text-sm text-gray-500">
          Reflect on this throughout your day
        </div>
      </CardContent>
    </Card>
  );
};

export default DailyAffirmation;