import React from 'react';
import { Book, FileText, Video, Compass } from 'lucide-react';
import { SpiritualResource } from '../types';
import Card, { CardContent, CardFooter } from './ui/Card';
import Button from './ui/Button';

interface ResourceCardProps {
  resource: SpiritualResource;
  onSelect: (resource: SpiritualResource) => void;
}

const ResourceCard: React.FC<ResourceCardProps> = ({ resource, onSelect }) => {
  const getIcon = () => {
    switch (resource.type) {
      case 'book':
        return <Book size={20} className="text-primary" />;
      case 'article':
        return <FileText size={20} className="text-secondary" />;
      case 'video':
        return <Video size={20} className="text-amber-500" />;
      case 'practice':
        return <Compass size={20} className="text-green-600" />;
      default:
        return null;
    }
  };

  return (
    <Card hover className="h-full flex flex-col">
      <CardContent className="flex-1">
        <div className="flex items-center gap-2 mb-3">
          {getIcon()}
          <span className="text-sm font-medium capitalize text-gray-500">
            {resource.type}
          </span>
        </div>
        <h3 className="text-xl font-semibold text-gray-800 mb-2">
          {resource.title}
        </h3>
        <p className="text-gray-600">{resource.description}</p>
      </CardContent>
      
      <CardFooter className="bg-gray-50">
        <Button 
          onClick={() => onSelect(resource)}
          variant="secondary" 
          isFullWidth
        >
          Explore
        </Button>
      </CardFooter>
    </Card>
  );
};

export default ResourceCard;