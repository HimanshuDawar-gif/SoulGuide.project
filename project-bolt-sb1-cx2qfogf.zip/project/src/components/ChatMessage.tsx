import React from 'react';
import { Message } from '../types';
import { formatTimestamp } from '../utils/helpers';

interface ChatMessageProps {
  message: Message;
}

const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const isGuide = message.type === 'guide';
  
  return (
    <div 
      className={`flex w-full mb-4 ${isGuide ? 'justify-start' : 'justify-end'}`}
    >
      <div 
        className={`
          max-w-[80%] md:max-w-[70%] p-4 rounded-lg relative
          ${isGuide 
            ? 'bg-gradient-to-r from-primary/80 to-primary text-white rounded-tl-none' 
            : 'bg-gray-100 text-gray-800 rounded-tr-none'
          }
        `}
      >
        {/* Message content */}
        <div className="prose prose-sm">
          {message.content.split('\n').map((paragraph, index) => (
            <p key={index} className={`mb-2 ${isGuide ? 'text-white' : 'text-gray-800'}`}>
              {paragraph}
            </p>
          ))}
        </div>

        {/* Timestamp */}
        <div 
          className={`
            text-xs mt-1 text-right
            ${isGuide ? 'text-white/70' : 'text-gray-500'}
          `}
        >
          {formatTimestamp(message.timestamp)}
        </div>
      </div>
    </div>
  );
};

export default ChatMessage;