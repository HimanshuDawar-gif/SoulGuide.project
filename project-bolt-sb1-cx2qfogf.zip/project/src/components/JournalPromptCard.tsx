import React from 'react';
import { Pencil } from 'lucide-react';
import { JournalPrompt } from '../types';
import Card, { CardContent, CardFooter } from './ui/Card';
import Button from './ui/Button';

const categoryColors = {
  'self-discovery': 'bg-blue-100 text-blue-800',
  'healing': 'bg-green-100 text-green-800',
  'growth': 'bg-purple-100 text-purple-800',
  'purpose': 'bg-amber-100 text-amber-800',
  'relationships': 'bg-pink-100 text-pink-800'
};

interface JournalPromptCardProps {
  prompt: JournalPrompt;
  onSelect: (prompt: JournalPrompt) => void;
}

const JournalPromptCard: React.FC<JournalPromptCardProps> = ({ prompt, onSelect }) => {
  const categoryClass = categoryColors[prompt.category];
  
  return (
    <Card hover className="h-full flex flex-col">
      <CardContent className="flex-1">
        <div className="flex justify-between items-start mb-3">
          <h3 className="text-xl font-semibold text-gray-800">
            {prompt.title}
          </h3>
          <span className={`text-xs px-2 py-1 rounded-full ${categoryClass}`}>
            {prompt.category.replace('-', ' ')}
          </span>
        </div>
        
        <p className="text-gray-600 italic">{prompt.prompt}</p>
      </CardContent>
      
      <CardFooter className="bg-gray-50">
        <Button 
          onClick={() => onSelect(prompt)}
          variant="outline" 
          isFullWidth
          leftIcon={<Pencil size={16} />}
        >
          Reflect on This
        </Button>
      </CardFooter>
    </Card>
  );
};

export default JournalPromptCard;