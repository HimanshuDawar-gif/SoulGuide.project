import React from 'react';
import { Clock } from 'lucide-react';
import { MeditationExercise } from '../types';
import Card, { CardContent, CardFooter } from './ui/Card';
import Button from './ui/Button';

interface MeditationCardProps {
  meditation: MeditationExercise;
  onStart: (meditation: MeditationExercise) => void;
}

const MeditationCard: React.FC<MeditationCardProps> = ({ meditation, onStart }) => {
  return (
    <Card hover className="h-full flex flex-col">
      <CardContent className="flex-1">
        <h3 className="text-xl font-semibold text-gray-800 mb-2">
          {meditation.title}
        </h3>
        
        <div className="flex items-center text-gray-500 mb-3">
          <Clock size={16} className="mr-1" />
          <span>{meditation.durationMinutes} minutes</span>
        </div>
        
        <p className="text-gray-600">{meditation.description}</p>
      </CardContent>
      
      <CardFooter className="bg-gray-50">
        <Button 
          onClick={() => onStart(meditation)}
          variant="primary" 
          isFullWidth
        >
          Begin Practice
        </Button>
      </CardFooter>
    </Card>
  );
};

export default MeditationCard;