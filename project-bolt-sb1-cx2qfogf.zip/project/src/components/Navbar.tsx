import React, { useState } from 'react';
import { Menu, X, Home, MessageCircle, BookOpen, Moon, Settings } from 'lucide-react';

interface NavItem {
  name: string;
  icon: React.ReactNode;
  isActive: boolean;
}

interface NavbarProps {
  currentPage: string;
  onNavigate: (page: string) => void;
}

const Navbar: React.FC<NavbarProps> = ({ currentPage, onNavigate }) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  const navItems: NavItem[] = [
    {
      name: 'Home',
      icon: <Home size={20} />,
      isActive: currentPage === 'home',
    },
    {
      name: 'Guidance',
      icon: <MessageCircle size={20} />,
      isActive: currentPage === 'guidance',
    },
    {
      name: 'Meditation',
      icon: <Moon size={20} />,
      isActive: currentPage === 'meditation',
    },
    {
      name: 'Resources',
      icon: <BookOpen size={20} />,
      isActive: currentPage === 'resources',
    },
    {
      name: 'Settings',
      icon: <Settings size={20} />,
      isActive: currentPage === 'settings',
    },
  ];

  const toggleMobileMenu = () => setIsMobileMenuOpen(!isMobileMenuOpen);
  
  return (
    <nav className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          {/* Logo and brand */}
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <div className="h-8 w-8 rounded-full bg-gradient-to-r from-primary to-secondary flex items-center justify-center">
                <span className="text-white font-bold">SG</span>
              </div>
              <span className="ml-2 text-xl font-semibold text-gray-800">SoulGuide</span>
            </div>
          </div>
          
          {/* Desktop navigation */}
          <div className="hidden md:flex items-center space-x-1">
            {navItems.map((item) => (
              <button
                key={item.name}
                onClick={() => onNavigate(item.name.toLowerCase())}
                className={`
                  px-3 py-2 rounded-md text-sm font-medium transition-colors
                  flex items-center space-x-2
                  ${item.isActive 
                    ? 'bg-primary/10 text-primary' 
                    : 'text-gray-600 hover:bg-gray-100'}
                `}
              >
                {item.icon}
                <span>{item.name}</span>
              </button>
            ))}
          </div>
          
          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <button
              onClick={toggleMobileMenu}
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-600 hover:text-gray-900 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-primary"
            >
              <span className="sr-only">Open main menu</span>
              {isMobileMenuOpen ? (
                <X className="block h-6 w-6" aria-hidden="true" />
              ) : (
                <Menu className="block h-6 w-6" aria-hidden="true" />
              )}
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            {navItems.map((item) => (
              <button
                key={item.name}
                onClick={() => {
                  onNavigate(item.name.toLowerCase());
                  setIsMobileMenuOpen(false);
                }}
                className={`
                  w-full flex items-center px-3 py-2 rounded-md text-base font-medium
                  ${item.isActive 
                    ? 'bg-primary/10 text-primary' 
                    : 'text-gray-600 hover:bg-gray-100'}
                `}
              >
                <span className="mr-3">{item.icon}</span>
                {item.name}
              </button>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;