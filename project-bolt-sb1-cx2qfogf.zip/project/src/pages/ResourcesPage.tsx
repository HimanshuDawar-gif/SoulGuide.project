import React, { useState } from 'react';
import { Book, FileText, Pencil, X } from 'lucide-react';
import { resources } from '../data/resources';
import { journalPrompts } from '../data/journalPrompts';
import { JournalPrompt, SpiritualResource } from '../types';
import ResourceCard from '../components/ResourceCard';
import JournalPromptCard from '../components/JournalPromptCard';
import Card, { CardContent, CardHeader } from '../components/ui/Card';
import Button from '../components/ui/Button';

const ResourcesPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'resources' | 'journal'>('resources');
  const [selectedResource, setSelectedResource] = useState<SpiritualResource | null>(null);
  const [selectedPrompt, setSelectedPrompt] = useState<JournalPrompt | null>(null);
  const [journalEntry, setJournalEntry] = useState('');

  const handleSelectResource = (resource: SpiritualResource) => {
    setSelectedResource(resource);
  };

  const handleSelectPrompt = (prompt: JournalPrompt) => {
    setSelectedPrompt(prompt);
  };

  const handleSaveJournalEntry = () => {
    // In a real app, this would save to a database
    alert('Journal entry saved! (Demo only - not actually saved)');
    setJournalEntry('');
    setSelectedPrompt(null);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-gray-800 mb-6">
        Spiritual Resources & Journal
      </h1>
      
      {/* Tabs */}
      <div className="flex border-b mb-8">
        <button
          onClick={() => setActiveTab('resources')}
          className={`py-2 px-4 font-medium ${
            activeTab === 'resources'
              ? 'text-primary border-b-2 border-primary'
              : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          <div className="flex items-center">
            <Book size={18} className="mr-2" />
            Resources
          </div>
        </button>
        
        <button
          onClick={() => setActiveTab('journal')}
          className={`py-2 px-4 font-medium ${
            activeTab === 'journal'
              ? 'text-primary border-b-2 border-primary'
              : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          <div className="flex items-center">
            <Pencil size={18} className="mr-2" />
            Journal Prompts
          </div>
        </button>
      </div>
      
      {/* Selected resource detail view */}
      {selectedResource && (
        <div className="mb-8">
          <Card>
            <CardHeader className="flex justify-between items-center">
              <h2 className="text-2xl font-semibold text-gray-800">
                {selectedResource.title}
              </h2>
              <Button
                variant="ghost"
                onClick={() => setSelectedResource(null)}
                leftIcon={<X size={18} />}
              >
                Close
              </Button>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">
                {selectedResource.description}
              </p>
              
              <div className="flex items-center text-sm text-gray-500 mb-4">
                <FileText size={16} className="mr-1" />
                <span className="capitalize">{selectedResource.type}</span>
              </div>
              
              <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                <h3 className="text-lg font-medium text-gray-800 mb-2">
                  How to Use This Resource
                </h3>
                <p className="text-gray-600">
                  {selectedResource.type === 'book' && 
                    "Take your time with this book. Consider keeping a journal to note passages that resonate with you. Reflect on how the teachings might apply to your own spiritual journey."}
                  {selectedResource.type === 'article' && 
                    "Read this article mindfully, perhaps highlighting sections that speak to you. Consider how the ideas presented might shift your perspective or deepen your practice."}
                  {selectedResource.type === 'practice' && 
                    "Try incorporating this practice into your daily routine for at least a week to observe its effects. Be gentle with yourself as you learn."}
                  {selectedResource.type === 'video' && 
                    "Watch this video in a quiet space where you can give it your full attention. Consider taking notes or revisiting sections that contain insights you want to remember."}
                </p>
              </div>
              
              <div className="mt-6">
                <Button variant="primary">
                  {selectedResource.link 
                    ? 'Visit Resource' 
                    : 'Learn More'}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
      
      {/* Journal prompt writing view */}
      {selectedPrompt && (
        <div className="mb-8">
          <Card>
            <CardHeader className="flex justify-between items-center">
              <h2 className="text-2xl font-semibold text-gray-800">
                {selectedPrompt.title}
              </h2>
              <Button
                variant="ghost"
                onClick={() => setSelectedPrompt(null)}
                leftIcon={<X size={18} />}
              >
                Close
              </Button>
            </CardHeader>
            <CardContent>
              <p className="text-xl italic text-gray-600 mb-6 border-l-4 border-primary pl-4 py-2">
                {selectedPrompt.prompt}
              </p>
              
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Your Reflection
                </label>
                <textarea
                  value={journalEntry}
                  onChange={(e) => setJournalEntry(e.target.value)}
                  rows={8}
                  className="w-full px-3 py-2 bg-white border border-gray-300 rounded-md text-gray-700 focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all duration-200"
                  placeholder="Begin writing your thoughts..."
                ></textarea>
              </div>
              
              <div className="flex justify-end space-x-3">
                <Button
                  variant="outline"
                  onClick={() => setSelectedPrompt(null)}
                >
                  Cancel
                </Button>
                <Button
                  variant="primary"
                  onClick={handleSaveJournalEntry}
                  disabled={!journalEntry.trim()}
                >
                  Save Reflection
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
      
      {/* Resources list */}
      {activeTab === 'resources' && !selectedResource && !selectedPrompt && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {resources.map((resource) => (
            <ResourceCard
              key={resource.id}
              resource={resource}
              onSelect={handleSelectResource}
            />
          ))}
        </div>
      )}
      
      {/* Journal prompts list */}
      {activeTab === 'journal' && !selectedResource && !selectedPrompt && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {journalPrompts.map((prompt) => (
            <JournalPromptCard
              key={prompt.id}
              prompt={prompt}
              onSelect={handleSelectPrompt}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default ResourcesPage;