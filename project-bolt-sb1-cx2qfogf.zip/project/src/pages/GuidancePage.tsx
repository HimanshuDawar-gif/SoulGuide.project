import React, { useState, useRef, useEffect } from 'react';
import { Send } from 'lucide-react';
import ChatMessage from '../components/ChatMessage';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import { Message } from '../types';
import { generateUniqueId, getRandomItem } from '../utils/helpers';
import { responseStarters, guidanceResponses, greetings } from '../data/guidanceMessages';

const GuidancePage: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: generateUniqueId(),
      type: 'guide',
      content: "Welcome to your spiritual guidance session. I'm here to offer wisdom, support, and insights tailored to your journey. What's on your mind or heart today?",
      timestamp: new Date(),
    },
  ]);
  
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const checkForGreeting = (message: string) => {
    const lowerMessage = message.toLowerCase();
    
    // Check for formal greetings
    if (lowerMessage.includes('namaste') || 
        lowerMessage.includes('greetings') || 
        lowerMessage.includes('good morning') || 
        lowerMessage.includes('good afternoon') || 
        lowerMessage.includes('good evening')) {
      return getRandomItem(greetings.formal);
    }
    
    // Check for casual greetings
    if (lowerMessage.startsWith('hi') || 
        lowerMessage.startsWith('hey') || 
        lowerMessage.startsWith('hello')) {
      return getRandomItem(greetings.casual);
    }
    
    // Check for friendly/informal greetings
    if (lowerMessage.includes('friend') || 
        lowerMessage.includes('buddy') || 
        lowerMessage.includes('mate') ||
        lowerMessage.includes('wassup') ||
        lowerMessage.includes("what's up")) {
      return getRandomItem(greetings.friendly);
    }
    
    return null;
  };

  const checkForMisbehavior = (message: string) => {
    const lowerMessage = message.toLowerCase();
    
    // Check for rude behavior
    if (lowerMessage.includes('stupid') || lowerMessage.includes('idiot') || 
        lowerMessage.includes('dumb') || lowerMessage.includes('shut up')) {
      return getRandomItem(guidanceResponses.misbehavior.rude);
    }
    
    // Check for CGPA mentions
    if (lowerMessage.includes('cgpa') || lowerMessage.includes('gpa') || 
        lowerMessage.includes('grades')) {
      return getRandomItem(guidanceResponses.misbehavior.cgpa);
    }
    
    // Check for dismissive behavior
    if (lowerMessage.includes('whatever') || lowerMessage.includes('go away') || 
        lowerMessage.includes('bye') || lowerMessage.includes('leave me alone')) {
      return getRandomItem(guidanceResponses.misbehavior.dismissive);
    }
    
    return null;
  };

  const generateEmotionalResponse = (message: string) => {
    const lowerMessage = message.toLowerCase();
    
    // Check for emotional keywords
    if (lowerMessage.includes('sad') || lowerMessage.includes('down') || lowerMessage.includes('blue')) {
      return getRandomItem(guidanceResponses.emotional.sadness);
    }
    if (lowerMessage.includes('anxi') || lowerMessage.includes('worry') || lowerMessage.includes('stress')) {
      return getRandomItem(guidanceResponses.emotional.anxiety);
    }
    if (lowerMessage.includes('anger') || lowerMessage.includes('angry') || lowerMessage.includes('frustrat')) {
      return getRandomItem(guidanceResponses.emotional.anger);
    }
    if (lowerMessage.includes('fear') || lowerMessage.includes('scared') || lowerMessage.includes('afraid')) {
      return getRandomItem(guidanceResponses.emotional.fear);
    }
    if (lowerMessage.includes('depress') || lowerMessage.includes('hopeless') || lowerMessage.includes('meaningless')) {
      return getRandomItem(guidanceResponses.emotional.depression);
    }
    
    return null;
  };

  const generateGuidanceResponse = (userMessage: string) => {
    setIsTyping(true);
    
    setTimeout(() => {
      let responseContent = '';
      
      // First check for greetings
      const greetingResponse = checkForGreeting(userMessage);
      if (greetingResponse) {
        responseContent = greetingResponse;
      }
      // Then check for misbehavior
      else {
        const misbehaviorResponse = checkForMisbehavior(userMessage);
        if (misbehaviorResponse) {
          responseContent = misbehaviorResponse;
        }
        // Then check for emotional content
        else {
          const emotionalResponse = generateEmotionalResponse(userMessage);
          if (emotionalResponse) {
            responseContent = emotionalResponse;
          }
          // Then check other topics
          else if (userMessage.toLowerCase().includes('meditat')) {
            responseContent = getRandomItem(guidanceResponses.meditation);
          } else if (userMessage.toLowerCase().includes('purpose')) {
            responseContent = getRandomItem(guidanceResponses.purpose);
          } else if (userMessage.toLowerCase().includes('heal')) {
            responseContent = getRandomItem(guidanceResponses.healing);
          } else if (userMessage.toLowerCase().includes('practice')) {
            responseContent = getRandomItem(guidanceResponses.spiritualPractices);
          } else {
            // Generic response
            const starter = getRandomItem(responseStarters);
            responseContent = `${starter} ${userMessage.toLowerCase().split(' ').slice(0, 3).join(' ')}... I encourage you to explore this through quiet reflection. What feels true to you in this moment?`;
          }
        }
      }
      
      const newMessage: Message = {
        id: generateUniqueId(),
        type: 'guide',
        content: responseContent,
        timestamp: new Date(),
      };
      
      setMessages((prev) => [...prev, newMessage]);
      setIsTyping(false);
    }, 1500);
  };

  const handleSendMessage = () => {
    if (!input.trim()) return;
    
    const userMessage: Message = {
      id: generateUniqueId(),
      type: 'user',
      content: input,
      timestamp: new Date(),
    };
    
    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    
    generateGuidanceResponse(input);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] max-w-3xl mx-auto">
      <div className="flex-1 overflow-y-auto p-4">
        <div className="space-y-4">
          {messages.map((message) => (
            <ChatMessage key={message.id} message={message} />
          ))}
          
          {isTyping && (
            <div className="flex items-center text-gray-500 ml-2">
              <div className="bounce-loading">
                <div className="bounce1"></div>
                <div className="bounce2"></div>
                <div className="bounce3"></div>
              </div>
              <span className="ml-2 text-sm">SoulGuide is typing...</span>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>
      </div>

      <div className="border-t p-4 bg-white/80 backdrop-blur-sm">
        <div className="flex gap-2">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyPress}
            placeholder="Share what's on your mind or heart..."
            fullWidth
          />
          <Button
            onClick={handleSendMessage}
            disabled={!input.trim() || isTyping}
            leftIcon={<Send size={16} />}
          >
            Send
          </Button>
        </div>
        <p className="text-xs text-gray-500 mt-2">
          Share your thoughts, feelings, or concerns. I'm here to listen and support your journey.
        </p>
      </div>
      
      <style jsx>{`
        .bounce-loading {
          display: inline-flex;
        }
        .bounce-loading > div {
          width: 8px;
          height: 8px;
          background-color: #7C4DFF;
          border-radius: 50%;
          margin: 0 2px;
          animation: bounce 1.4s infinite ease-in-out both;
        }
        .bounce-loading .bounce1 {
          animation-delay: -0.32s;
        }
        .bounce-loading .bounce2 {
          animation-delay: -0.16s;
        }
        @keyframes bounce {
          0%, 80%, 100% { transform: scale(0); }
          40% { transform: scale(1.0); }
        }
      `}</style>
    </div>
  );
};

export default GuidancePage;