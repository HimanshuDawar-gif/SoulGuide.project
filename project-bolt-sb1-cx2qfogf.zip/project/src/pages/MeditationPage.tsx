import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw } from 'lucide-react';
import { meditations } from '../data/meditations';
import Button from '../components/ui/Button';
import MeditationCard from '../components/MeditationCard';
import { MeditationExercise } from '../types';

const MeditationPage: React.FC = () => {
  const [activeMeditation, setActiveMeditation] = useState<MeditationExercise | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState(0);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (activeMeditation) {
      setTimeRemaining(activeMeditation.durationMinutes * 60);
    }
    
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [activeMeditation]);

  const handleStartMeditation = (meditation: MeditationExercise) => {
    setActiveMeditation(meditation);
    setTimeRemaining(meditation.durationMinutes * 60);
    setIsPlaying(false);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const togglePlayPause = () => {
    if (isPlaying) {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    } else {
      timerRef.current = setInterval(() => {
        setTimeRemaining((prev) => {
          if (prev <= 1) {
            clearInterval(timerRef.current as NodeJS.Timeout);
            setIsPlaying(false);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    setIsPlaying(!isPlaying);
  };

  const resetTimer = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    if (activeMeditation) {
      setTimeRemaining(activeMeditation.durationMinutes * 60);
    }
    setIsPlaying(false);
  };

  const backToMeditations = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    setActiveMeditation(null);
    setIsPlaying(false);
  };

  const calculateProgress = () => {
    if (!activeMeditation) return 0;
    const total = activeMeditation.durationMinutes * 60;
    const completed = total - timeRemaining;
    return (completed / total) * 100;
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-gray-800 mb-6">Meditation & Mindfulness</h1>
      
      {!activeMeditation ? (
        <>
          <p className="text-gray-600 mb-8">
            Discover peace and presence through these guided meditation practices.
            Choose a meditation to begin your practice.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {meditations.map((meditation) => (
              <MeditationCard
                key={meditation.id}
                meditation={meditation}
                onStart={handleStartMeditation}
              />
            ))}
          </div>
        </>
      ) : (
        <div className="bg-white rounded-lg shadow-md p-6 max-w-xl mx-auto">
          <h2 className="text-2xl font-bold text-gray-800 text-center mb-2">
            {activeMeditation.title}
          </h2>
          <p className="text-gray-600 text-center mb-8">
            {activeMeditation.description}
          </p>
          
          <div className="mb-6">
            <div className="w-full bg-gray-200 rounded-full h-4 mb-2">
              <div 
                className="bg-primary h-4 rounded-full transition-all duration-1000 ease-linear"
                style={{ width: `${calculateProgress()}%` }}
              ></div>
            </div>
            
            <div className="text-4xl font-mono text-center font-bold text-gray-800">
              {formatTime(timeRemaining)}
            </div>
          </div>
          
          <div className="flex justify-center space-x-4 mb-6">
            <Button
              onClick={togglePlayPause}
              variant="primary"
              size="lg"
              leftIcon={isPlaying ? <Pause size={20} /> : <Play size={20} />}
            >
              {isPlaying ? 'Pause' : 'Start'}
            </Button>
            
            <Button
              onClick={resetTimer}
              variant="outline"
              size="lg"
              leftIcon={<RotateCcw size={20} />}
            >
              Reset
            </Button>
          </div>
          
          <div className="text-center">
            <Button
              onClick={backToMeditations}
              variant="link"
            >
              Choose Different Meditation
            </Button>
          </div>
          
          {isPlaying && (
            <div className="mt-8 p-4 bg-gray-50 rounded-lg border border-gray-200">
              <p className="text-gray-700 text-center font-serif italic">
                Breathe deeply and relax. Allow yourself to be fully present in this moment.
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default MeditationPage;