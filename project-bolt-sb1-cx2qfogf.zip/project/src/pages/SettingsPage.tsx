import React, { useState } from 'react';
import { Save } from 'lucide-react';
import Button from '../components/ui/Button';
import { UserPreference } from '../types';

const SettingsPage: React.FC = () => {
  const [preferences, setPreferences] = useState<UserPreference>({
    spiritualInterests: ['mindfulness', 'meditation'],
    experienceLevel: 'beginner',
    preferredPractices: ['daily-reflection'],
    favoriteResources: [],
  });

  const spiritualInterestOptions = [
    { id: 'mindfulness', label: 'Mindfulness' },
    { id: 'meditation', label: 'Meditation' },
    { id: 'energy-work', label: 'Energy Work' },
    { id: 'tarot', label: 'Tarot & Divination' },
    { id: 'eastern', label: 'Eastern Philosophies' },
    { id: 'western', label: 'Western Mysticism' },
    { id: 'shamanic', label: 'Shamanic Practices' },
    { id: 'crystals', label: 'Crystal Healing' },
    { id: 'astrology', label: 'Astrology' },
  ];

  const practiceOptions = [
    { id: 'daily-reflection', label: 'Daily Reflection' },
    { id: 'meditation', label: 'Meditation' },
    { id: 'journaling', label: 'Journaling' },
    { id: 'energy-practice', label: 'Energy Practice' },
    { id: 'prayer', label: 'Prayer' },
    { id: 'ritual', label: 'Ritual Work' },
    { id: 'divination', label: 'Divination' },
    { id: 'movement', label: 'Movement Practice' },
  ];

  const handleInterestChange = (interestId: string) => {
    setPreferences((prev) => {
      if (prev.spiritualInterests.includes(interestId)) {
        return {
          ...prev,
          spiritualInterests: prev.spiritualInterests.filter(id => id !== interestId),
        };
      } else {
        return {
          ...prev,
          spiritualInterests: [...prev.spiritualInterests, interestId],
        };
      }
    });
  };

  const handlePracticeChange = (practiceId: string) => {
    setPreferences((prev) => {
      if (prev.preferredPractices.includes(practiceId)) {
        return {
          ...prev,
          preferredPractices: prev.preferredPractices.filter(id => id !== practiceId),
        };
      } else {
        return {
          ...prev,
          preferredPractices: [...prev.preferredPractices, practiceId],
        };
      }
    });
  };

  const handleExperienceLevelChange = (level: 'beginner' | 'intermediate' | 'advanced') => {
    setPreferences((prev) => ({
      ...prev,
      experienceLevel: level,
    }));
  };

  const handleSavePreferences = () => {
    // In a real app, this would save to a database or localStorage
    alert('Preferences saved! (Demo only - not actually saved)');
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-gray-800 mb-6">Settings & Preferences</h1>
      <p className="text-gray-600 mb-8">
        Customize your spiritual guidance experience. These preferences help tailor the content and recommendations to your unique journey.
      </p>
      
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-xl font-semibold text-gray-800 mb-4">
          Spiritual Interests
        </h2>
        <p className="text-gray-600 mb-4">
          Select the topics and traditions that resonate with you.
        </p>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 mb-6">
          {spiritualInterestOptions.map((interest) => (
            <label 
              key={interest.id}
              className="flex items-center space-x-2 cursor-pointer"
            >
              <input
                type="checkbox"
                className="h-5 w-5 text-primary rounded focus:ring-primary"
                checked={preferences.spiritualInterests.includes(interest.id)}
                onChange={() => handleInterestChange(interest.id)}
              />
              <span className="text-gray-700">{interest.label}</span>
            </label>
          ))}
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-xl font-semibold text-gray-800 mb-4">
          Experience Level
        </h2>
        <p className="text-gray-600 mb-4">
          How would you describe your spiritual practice experience?
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <label 
            className={`
              flex items-center p-4 border rounded-lg cursor-pointer transition-all
              ${preferences.experienceLevel === 'beginner'
                ? 'border-primary bg-primary/5'
                : 'border-gray-200 hover:bg-gray-50'}
            `}
          >
            <input
              type="radio"
              className="sr-only"
              checked={preferences.experienceLevel === 'beginner'}
              onChange={() => handleExperienceLevelChange('beginner')}
            />
            <div>
              <div className="font-medium text-gray-800">Beginner</div>
              <div className="text-sm text-gray-500">New to spiritual practice</div>
            </div>
          </label>
          
          <label 
            className={`
              flex items-center p-4 border rounded-lg cursor-pointer transition-all
              ${preferences.experienceLevel === 'intermediate'
                ? 'border-primary bg-primary/5'
                : 'border-gray-200 hover:bg-gray-50'}
            `}
          >
            <input
              type="radio"
              className="sr-only"
              checked={preferences.experienceLevel === 'intermediate'}
              onChange={() => handleExperienceLevelChange('intermediate')}
            />
            <div>
              <div className="font-medium text-gray-800">Intermediate</div>
              <div className="text-sm text-gray-500">Some experience with practice</div>
            </div>
          </label>
          
          <label 
            className={`
              flex items-center p-4 border rounded-lg cursor-pointer transition-all
              ${preferences.experienceLevel === 'advanced'
                ? 'border-primary bg-primary/5'
                : 'border-gray-200 hover:bg-gray-50'}
            `}
          >
            <input
              type="radio"
              className="sr-only"
              checked={preferences.experienceLevel === 'advanced'}
              onChange={() => handleExperienceLevelChange('advanced')}
            />
            <div>
              <div className="font-medium text-gray-800">Advanced</div>
              <div className="text-sm text-gray-500">Dedicated spiritual practitioner</div>
            </div>
          </label>
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-xl font-semibold text-gray-800 mb-4">
          Preferred Practices
        </h2>
        <p className="text-gray-600 mb-4">
          Select the spiritual practices you're most drawn to.
        </p>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 mb-6">
          {practiceOptions.map((practice) => (
            <label 
              key={practice.id}
              className="flex items-center space-x-2 cursor-pointer"
            >
              <input
                type="checkbox"
                className="h-5 w-5 text-primary rounded focus:ring-primary"
                checked={preferences.preferredPractices.includes(practice.id)}
                onChange={() => handlePracticeChange(practice.id)}
              />
              <span className="text-gray-700">{practice.label}</span>
            </label>
          ))}
        </div>
      </div>
      
      <div className="text-right">
        <Button
          onClick={handleSavePreferences}
          variant="primary"
          size="lg"
          leftIcon={<Save size={18} />}
        >
          Save Preferences
        </Button>
      </div>
    </div>
  );
};

export default SettingsPage;