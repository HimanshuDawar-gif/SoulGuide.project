import React from 'react';
import { ChevronRight, Heart, Brain, Sparkles, Compass } from 'lucide-react';
import DailyAffirmation from '../components/DailyAffirmation';
import Button from '../components/ui/Button';
import Card from '../components/ui/Card';
import { getRandomItem } from '../utils/helpers';
import { welcomeMessages } from '../data/guidanceMessages';

interface HomePageProps {
  onNavigate: (page: string) => void;
}

const HomePage: React.FC<HomePageProps> = ({ onNavigate }) => {
  const welcomeMessage = getRandomItem(welcomeMessages);

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-800 mb-4">
          Welcome to <span className="text-primary">SoulGuide</span>
        </h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Your personal spiritual companion on the journey to inner wisdom and growth.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-8 mb-12">
        <Card className="p-6">
          <h2 className="text-2xl font-serif text-gray-800 mb-4">
            What is Spirituality?
          </h2>
          <p className="text-gray-600 mb-4">
            Spirituality is a deeply personal journey of self-discovery and connection to something greater than ourselves. It's about finding meaning, purpose, and understanding our place in the universe.
          </p>
          <p className="text-gray-600">
            Unlike organized religion, spirituality is a flexible path that can incorporate various beliefs, practices, and traditions that resonate with your personal truth and values.
          </p>
        </Card>

        <Card className="p-6">
          <h2 className="text-2xl font-serif text-gray-800 mb-4">
            Daily Benefits of Spirituality
          </h2>
          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <div className="p-2 bg-primary/10 rounded-lg">
                <Heart className="w-5 h-5 text-primary" />
              </div>
              <div>
                <h3 className="font-medium text-gray-800">Inner Peace</h3>
                <p className="text-gray-600">Reduced stress and anxiety through mindfulness and meditation</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="p-2 bg-secondary/10 rounded-lg">
                <Brain className="w-5 h-5 text-secondary" />
              </div>
              <div>
                <h3 className="font-medium text-gray-800">Mental Clarity</h3>
                <p className="text-gray-600">Better decision-making and emotional regulation</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="p-2 bg-accent/10 rounded-lg">
                <Sparkles className="w-5 h-5 text-accent" />
              </div>
              <div>
                <h3 className="font-medium text-gray-800">Personal Growth</h3>
                <p className="text-gray-600">Enhanced self-awareness and meaningful relationships</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="p-2 bg-success/10 rounded-lg">
                <Compass className="w-5 h-5 text-success" />
              </div>
              <div>
                <h3 className="font-medium text-gray-800">Life Purpose</h3>
                <p className="text-gray-600">Greater sense of meaning and direction in daily life</p>
              </div>
            </div>
          </div>
        </Card>
      </div>

      <div className="bg-white rounded-xl shadow-soft p-6 mb-12">
        <div className="flex flex-col md:flex-row gap-6 items-center">
          <div className="flex-1">
            <h2 className="text-2xl font-serif text-gray-800 mb-4">
              {welcomeMessage}
            </h2>
            <p className="text-gray-600 mb-6">
              Begin your spiritual journey with SoulGuide. We offer personalized guidance,
              meditation exercises, journal prompts, and resources to support your unique path
              to inner wisdom and growth.
            </p>
            <Button
              onClick={() => onNavigate('guidance')}
              rightIcon={<ChevronRight size={16} />}
              variant="primary"
              size="lg"
            >
              Start Your Journey
            </Button>
          </div>
          <div className="w-full md:w-1/3">
            <img
              src="https://images.pexels.com/photos/3560044/pexels-photo-3560044.jpeg?auto=compress&cs=tinysrgb&w=600"
              alt="Spiritual Journey"
              className="rounded-lg w-full h-auto shadow-lg"
            />
          </div>
        </div>
      </div>

      <div className="mb-12">
        <DailyAffirmation />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div 
          onClick={() => onNavigate('guidance')}
          className="bg-gradient-to-br from-primary/90 to-primary rounded-xl shadow-soft p-6 text-white cursor-pointer transform transition-all duration-300 hover:-translate-y-1 hover:shadow-glow"
        >
          <h3 className="text-xl font-semibold mb-2">Spiritual Guidance</h3>
          <p>Connect with wisdom and receive personalized spiritual guidance.</p>
        </div>
        
        <div 
          onClick={() => onNavigate('meditation')}
          className="bg-gradient-to-br from-secondary/90 to-secondary rounded-xl shadow-soft p-6 text-white cursor-pointer transform transition-all duration-300 hover:-translate-y-1 hover:shadow-glow"
        >
          <h3 className="text-xl font-semibold mb-2">Meditation</h3>
          <p>Discover peace with guided meditations and mindfulness practices.</p>
        </div>
        
        <div 
          onClick={() => onNavigate('resources')}
          className="bg-gradient-to-br from-accent/90 to-accent rounded-xl shadow-soft p-6 text-white cursor-pointer transform transition-all duration-300 hover:-translate-y-1 hover:shadow-glow"
        >
          <h3 className="text-xl font-semibold mb-2">Spiritual Resources</h3>
          <p>Explore curated resources and journal prompts for your journey.</p>
        </div>
      </div>
    </div>
  );
};

export default HomePage;