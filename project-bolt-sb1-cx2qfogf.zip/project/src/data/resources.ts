import { SpiritualResource } from '../types';

export const resources: SpiritualResource[] = [
  {
    id: '1',
    title: 'The Power of Now',
    description: 'Eckhart Tolle\'s guide to spiritual enlightenment through present moment awareness.',
    type: 'book',
  },
  {
    id: '2',
    title: 'Mindfulness Practice Guide',
    description: 'A comprehensive article on establishing a daily mindfulness routine.',
    type: 'article',
  },
  {
    id: '3',
    title: 'Sacred Morning Ritual',
    description: 'Step-by-step guide to creating a meaningful morning practice.',
    type: 'practice',
  },
  {
    id: '4',
    title: 'Understanding the Tarot',
    description: 'An introduction to tarot symbolism and personal interpretation.',
    type: 'video',
  },
  {
    id: '5',
    title: 'The Four Agreements',
    description: 'Don Miguel Ruiz shares ancient Toltec wisdom for personal freedom.',
    type: 'book',
  },
  {
    id: '6',
    title: 'Breathing Techniques for Anxiety',
    description: 'Simple breathing practices to calm the nervous system.',
    type: 'practice',
  },
  {
    id: '7',
    title: 'Understanding Sacred Geometry',
    description: 'Explore how geometric patterns connect to spiritual understanding.',
    type: 'article',
  },
  {
    id: '8',
    title: 'Connecting With Your Intuition',
    description: 'Practical exercises to strengthen your inner guidance system.',
    type: 'video',
  },
];