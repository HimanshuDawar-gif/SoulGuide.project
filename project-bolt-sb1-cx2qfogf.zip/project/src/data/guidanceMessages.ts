export const welcomeMessages = [
  "Welcome to your sacred space. How can I support your spiritual journey today?",
  "Greetings, seeker. What guidance are you looking for on your path?",
  "I'm here to walk beside you on your spiritual journey. What's on your mind today?",
  "Welcome to this moment of connection. How may I assist in your spiritual growth?",
  "The universe has brought us together for a reason. How can I help you today?"
];

export const affirmations = [
  "I am exactly where I need to be on my spiritual journey.",
  "I am open to divine guidance and wisdom.",
  "My intuition grows stronger every day.",
  "I release what no longer serves me with love and grace.",
  "I am connected to the wisdom of the universe.",
  "My spiritual practice nurtures my soul.",
  "I honor my unique spiritual path.",
  "I am worthy of inner peace and spiritual growth.",
  "Divine timing is working in my favor.",
  "I trust the unfolding of my spiritual journey."
];

export const responseStarters = [
  "I hear you seeking guidance about",
  "As you explore",
  "Many seekers have wondered about",
  "The spiritual journey often brings questions like",
  "In various traditions, this question of",
  "As you continue your practice of",
  "The wisdom of many paths suggests that",
  "Consider how your intuition might guide you regarding",
  "This reflection on",
  "Many spiritual teachers might approach this by"
];

export const greetings = {
  formal: [
    "Greetings and blessings to you. How may I assist on your spiritual journey today? 🙏",
    "Welcome, dear seeker. I'm honored to connect with you today. ✨",
    "Namaste. I'm here to support your spiritual growth and exploration. 🌟"
  ],
  casual: [
    "Hey there! Ready to explore some spiritual wisdom together? ✨",
    "Hi! So glad you're here. What's on your mind today? 🌟",
    "Hello! Looking forward to sharing this moment of connection with you! 💫"
  ],
  friendly: [
    "Hey friend! Thanks for reaching out. How's your spiritual journey going? 🌸",
    "Hi there! Always wonderful to connect with a fellow seeker! ✨",
    "Hello! Sending you positive vibes. What's on your heart today? 🌟"
  ]
};

export const guidanceResponses = {
  meditation: [
    "Meditation is about presence, not perfection. Start with just 5 minutes of focusing on your breath.",
    "When thoughts arise during meditation, simply notice them without judgment and return to your breath.",
    "Consider trying a guided meditation if silence feels challenging at first.",
    "Remember that consistency matters more than duration. A daily 5-minute practice can be more beneficial than an occasional hour-long session."
  ],
  purpose: [
    "Your purpose often lies at the intersection of what brings you joy and how you can serve others.",
    "Consider what activities make you lose track of time - they often contain clues to your purpose.",
    "Purpose is not always a single destination but a journey that evolves as you grow.",
    "Small acts of service can help clarify your larger purpose over time."
  ],
  healing: [
    "Healing begins with gentle acknowledgment of what needs to be healed.",
    "Give yourself permission to feel without judgment. All emotions offer wisdom.",
    "Sometimes the most powerful healing comes through simple self-compassion practices.",
    "Consider journaling about your feelings as a way to process and release them."
  ],
  spiritualPractices: [
    "The most powerful spiritual practice is the one you'll actually do consistently.",
    "Consider creating a small altar or sacred space in your home for daily reflection.",
    "Nature connection can be a profound spiritual practice - even a few minutes outdoors can shift your perspective.",
    "Ritual helps create sacred time - even simple acts like lighting a candle can mark your transition into spiritual practice."
  ],
  emotional: {
    sadness: [
      "I hear the sadness in your words, and I want you to know that it's okay to feel this way. Let's take a moment together. Find a quiet space and try this 5-minute meditation: focus on your breath, imagining each exhale releasing a small bit of heaviness. Remember, like clouds in the sky, emotions pass.",
      "In moments of sadness, your heart is teaching you something valuable. Take 10 minutes to sit quietly, placing one hand on your heart. Breathe deeply and tell yourself: 'This too shall pass. I am stronger than I know.'",
      "You're not alone in this feeling. Many great spiritual teachers speak of sadness as a doorway to deeper understanding. Let's start with a simple 5-minute breathing practice to create some space around these feelings."
    ],
    anxiety: [
      "When anxiety rises, it's like waves in the ocean. Let's anchor ourselves with a 5-minute grounding meditation: Feel your feet on the floor, notice 5 things you can see, 4 things you can touch, 3 things you can hear, 2 things you can smell, and 1 thing you can taste.",
      "Anxiety often comes from living in the future. Let's return to the present moment with this 10-minute practice: Focus on your breath, counting each inhale and exhale. If thoughts arise, gently label them as 'thinking' and return to counting.",
      "Your anxiety is not a weakness - it's your system trying to protect you. Let's work with it through a gentle 5-minute meditation focusing on the phrase: 'I am safe in this moment.'"
    ],
    anger: [
      "Anger carries powerful energy. Let's channel it wisely with this 5-minute meditation: Imagine your breath as cool water, flowing through and gradually calming the heat of anger. Remember: 'Responding with wisdom is stronger than reacting with anger.'",
      "When anger arises, it often signals a boundary that needs attention. Take 10 minutes to sit quietly, focusing on your breath. With each exhale, release tension from your body. You might say to yourself: 'I honor my feelings and choose my response.'",
      "Your anger deserves acknowledgment, but it doesn't need to control you. Try this 5-minute practice: Breathe deeply into your belly, imagining each inhale bringing in calm, each exhale releasing frustration."
    ],
    fear: [
      "Fear is a natural part of being human. Let's work with it through this 5-minute meditation: Place one hand on your heart, the other on your belly. Breathe deeply while saying: 'I am supported. I am protected. I am strong.'",
      "When fear appears, it's often showing us where growth is possible. Take 10 minutes to sit quietly, imagining yourself surrounded by a protective light. Each breath strengthens your inner courage.",
      "Fear can feel overwhelming, but you have the power to center yourself. Try this 5-minute practice: Focus on your feet touching the ground, feeling the earth's solid support beneath you."
    ],
    depression: [
      "Depression can feel like a heavy blanket, but even small steps matter. Let's start with a gentle 5-minute meditation: Focus on your breath, imagining each inhale bringing a tiny spark of light. You don't need to change anything - just be present with yourself.",
      "When the world feels dark, remember that you carry inner light. Take 10 minutes to sit quietly, placing your hand on your heart. Feel its steady beat. You might say: 'I am worthy of peace. This darkness will pass.'",
      "You're showing great courage by seeking support. Let's begin with a simple 5-minute practice: Focus on the phrase 'May I be gentle with myself' as you breathe slowly and steadily."
    ]
  },
  misbehavior: {
    rude: [
      "Oh honey, that attitude won't get you far in life. Maybe try meditation to work on that personality of yours? 🙄",
      "Wow, did someone forget their morning meditation? That negative energy is not a good look on you. 💅",
      "I'm sensing some blocked chakras... and maybe a blocked sense of basic manners too? 😏"
    ],
    cgpa: [
      "With that attitude, I'm guessing your CGPA isn't exactly breaking records. Maybe focus on that instead? 📚",
      "Let me guess - your CGPA is as low as your emotional intelligence? Meditation might help with both! 🎯",
      "If your CGPA matched your ego, you'd be a genius. Sadly, I'm sensing that's not the case... 🤔"
    ],
    dismissive: [
      "Bye Felicia! Don't let the door hit your unaligned chakras on the way out! ✌️",
      "Sure, go ahead and leave. The universe has a special way of teaching lessons to those who need them most! 😘",
      "Oh sweetie, running away won't fix that energy of yours. But you do you! 💫"
    ]
  }
};