import { JournalPrompt } from '../types';

export const journalPrompts: JournalPrompt[] = [
  {
    id: '1',
    title: 'Reflecting on Inner Peace',
    prompt: 'What does inner peace feel like to you? Describe a moment when you felt truly at peace.',
    category: 'self-discovery',
  },
  {
    id: '2',
    title: 'Exploring Your Spiritual Path',
    prompt: 'How has your spiritual journey evolved over time? What has been most meaningful?',
    category: 'growth',
  },
  {
    id: '3',
    title: 'Healing Through Reflection',
    prompt: 'What part of yourself needs healing right now? How might you begin that process?',
    category: 'healing',
  },
  {
    id: '4',
    title: 'Discovering Purpose',
    prompt: 'What activities make you lose track of time? How might they connect to your purpose?',
    category: 'purpose',
  },
  {
    id: '5',
    title: 'Sacred Relationships',
    prompt: 'Which relationship in your life has taught you the most about yourself? What did you learn?',
    category: 'relationships',
  },
  {
    id: '6',
    title: 'Daily Gratitude',
    prompt: 'Name three things you\'re grateful for today and explain why they bring you joy.',
    category: 'growth',
  },
  {
    id: '7',
    title: 'Shadow Work',
    prompt: 'What aspect of yourself do you find hardest to accept? How might embracing it help you grow?',
    category: 'healing',
  },
  {
    id: '8',
    title: 'Life\'s Teachers',
    prompt: 'Who has been a spiritual teacher in your life? What wisdom did they share?',
    category: 'growth',
  },
];