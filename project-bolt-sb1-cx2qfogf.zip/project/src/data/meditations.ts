import { MeditationExercise } from '../types';

export const meditations: MeditationExercise[] = [
  {
    id: '1',
    title: 'Breath Awareness',
    description: 'A gentle meditation focusing on the breath to anchor you in the present moment.',
    durationMinutes: 5,
  },
  {
    id: '2',
    title: 'Body Scan Relaxation',
    description: 'Systematically release tension throughout your body with this calming practice.',
    durationMinutes: 10,
  },
  {
    id: '3',
    title: 'Loving-Kindness Meditation',
    description: 'Cultivate compassion for yourself and others through this heart-centered practice.',
    durationMinutes: 15,
  },
  {
    id: '4',
    title: 'Chakra Balancing',
    description: 'Harmonize your energy centers with visualization and focused attention.',
    durationMinutes: 20,
  },
  {
    id: '5',
    title: 'Mindful Walking',
    description: 'Bring awareness to each step and connect with the earth beneath you.',
    durationMinutes: 10,
  },
  {
    id: '6',
    title: 'Gratitude Meditation',
    description: 'Open your heart by focusing on the blessings in your life.',
    durationMinutes: 7,
  },
];